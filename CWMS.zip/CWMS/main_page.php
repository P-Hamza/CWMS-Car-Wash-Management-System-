<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // values from form (use null coalescing for safety)
    $service_type = isset($_POST['service_type']) ? $_POST['service_type'] : null;
    $washing_point_id = isset($_POST['washing_point_id']) ? (int)$_POST['washing_point_id'] : null; // cast to int
    $vehicle_number = isset($_POST['vehicle_number']) ? $_POST['vehicle_number'] : null;
    $vehicle_type = isset($_POST['vehicle_type']) ? $_POST['vehicle_type'] : null;
    $wash_date = isset($_POST['Wash_date']) ? $_POST['Wash_date'] : null;
    $wash_time = isset($_POST['Wash_time']) ? $_POST['Wash_time'] : null;

    // ✅ get email from cookie
    $user_email = isset($_COOKIE['user_email']) ? $_COOKIE['user_email'] : null;

    if ($user_email === null) {
        die("❌ User not logged in (cookie not found).");
    }

    // Basic validation
    if (empty($service_type) || empty($washing_point_id) || empty($vehicle_number) || empty($vehicle_type) || empty($wash_date)) {
        die("❌ Please fill all required fields.");
    }

    // ✅ Insert without user_id, using user_email instead
    $sql = "INSERT INTO booking 
        (user_email, washing_point_id, service_type, vehicle_number, vehicle_type, Wash_date, Wash_time, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die("SQL Prepare Failed: " . mysqli_error($conn));
    }

    // bind params: s = string (user_email), i = int (washing_point_id), s... rest strings
    mysqli_stmt_bind_param($stmt, "sisssss", 
        $user_email, 
        $washing_point_id, 
        $service_type, 
        $vehicle_number, 
        $vehicle_type, 
        $wash_date, 
        $wash_time
    );

    if (mysqli_stmt_execute($stmt)) {
        echo "✅ Booking Confirm.<br>";
    } else {
        echo "❌ Insert Failed: " . mysqli_stmt_error($stmt) . "<br>";
    }

    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Car Wash Management - Home</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <!-- Font for close visual match -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css"> 
    <style>
      /* Minimal inline tweaks so modal displays properly even if style.css missing */
      .modal-backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); align-items: center; justify-content: center; z-index: 50; }
      .modal { background: #fff; padding: 20px; border-radius: 8px; width: 360px; max-width: 95%; }
      .form-row { margin-bottom: 12px; }
      label { display:block; margin-bottom:6px; font-weight:600; }
      input[type="text"], input[type="date"], input[type="time"], select { width:100%; padding:8px; border:1px solid #ccc; border-radius:4px; }
      .actions { display:flex; gap:8px; justify-content:flex-end; margin-top:12px; }
      .btn { padding:8px 12px; border:none; background:#0b74de; color:#fff; border-radius:6px; cursor:pointer; }
      .btn.alt { background:#777; }
    </style>
</head>

<body>


   <!-- TOP BAR -->
<div class="topbar" id="topbar">
        <div class="inner">
            <div class="logo"><span style="color:var(--accent)">CAR</span><span class="dark">Wash</span></div>
            <div class="top-info">
                <div class="item"><strong>Opening Hour</strong><small>⏰  Mon - Sat: 8:00 AM - 9:00 PM</small></div>
                <div class="item"><strong>Call Us</strong><small> 📞 +91 9558893914</small></div>
                <div class="item"><strong>Email</strong><small> ✉ carwash@gmail.com</small></div>
            </div>
        </div>
    </div>




    <!-- NAV BAR -->
    <div class="nav-bar" id="navBar">
        <div class="nav-inner">
            <ul class="nav-links" role="navigation" aria-label="Main Nav">
                <li><a href="main_page.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="plans.php">WASHING PLANS</a></li>
                <li><a href="points.php">WASHING POINTS</a></li>
                <li><a href="complaint.php">COMPLAINT</a></li>
                <li><a href="appoinment.php">APPOINMENT</a></li>
            </ul>
            <div class="nav-cta">
                <p><button class="btn" id="openBooking" onclick="openBookingModal('Basic Cleaning')">Get Appointment</button></p>
                
            </div>
        </div>
    </div>

    <!-- HERO -->
    <main>
        <div class="hero" id="hero">
            <div class="slides" id="slides">
                <div class="slide" style="background-image:url('img/carousel-1.jpg')">
                    <div class="slide-content">
                        <div class="kicker">WASHING & DETAILING</div>
                        <h1>Keep Your Car Newer</h1>
                        <p class="lead">Complete cleaning packages to keep your car looking new.</p>
                    </div>
                </div>
                <div class="slide" style="background-image:url('img/carousel-2.jpg')">
                    <div class="slide-content">
                        <div class="kicker">WASHING & DETAILING</div>
                        <h1>Exterior & Interior Washing</h1>
                        <p class="lead">Quality service and safe products for your vehicle.</p>
                    </div>
                </div>
                <div class="slide" style="background-image:url('img/carousel-3.jpg')">
                    <div class="slide-content">
                        <div class="kicker">WASHING & DETAILING</div>
                        <h1>Quality Service For You</h1>
                        <p class="lead">Fast, reliable, and affordable car care.</p>
                    </div>
                </div>
            </div>

            <div class="controls">
                <button class="ctrl" id="prev">&#10094;</button>
                <button class="ctrl" id="next">&#10095;</button>
            </div>
        </div>

        <!-- ABOUT -->
        <section class="about container1">
            <div class="left"><img src="img/about.jpg" alt="About image"></div>
            <div class="right">
                <div class="section-kicker">ABOUT US</div>
                <div class="section-title">Car Washing And Detailing</div>
                <p>“Our team provides professional car wash and detailing — reliable, quick, and safe. Your car will look as good as new.”</p>
                <ul>
                    <li>Seats washing</li>
                    <li>Vacuum cleaning</li>
                    <li>Interior wet cleaning</li>
                    <li>Window wiping</li>
                </ul>
                <p style="margin-top:12px"><button class="btn-custom" onclick="alert('Learn more')">Learn More</button></p>
            </div>
        </section>

        <!-- SERVICES -->
        <section class="services">
            <div class="container">
                <div class="section-header">
                    <p>WHAT WE DO?</p>
                    <h2>Premium Washing Services</h2>
                </div>

                <div class="service-grid">
                    <div class="service-card">
                        <div class="service-icon">🚗</div>
                        <h4>Exterior Washing</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🧼</div>
                        <h4>Interior Washing</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🧹</div>
                        <h4>Vacuum Cleaning</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🪑</div>
                        <h4>Seats Washing</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🪟</div>
                        <h4>Window Wiping</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">💧</div>
                        <h4>Wet Cleaning</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🛢️</div>
                        <h4>Oil Changing</h4>
                    </div>
                    <div class="service-card">
                        <div class="service-icon">🛠️</div>
                        <h4>Brake Repairing</h4>
                    </div>
                </div>
            </div>
        </section>

        <!-- FACTS -->
        <section class="facts container" aria-hidden="false">
            <div class="fact">
                <h3>25+</h3>
                <p>Service Points</p>
            </div>
            <div class="fact">
                <h3>350+</h3>
                <p>Engineers & Workers</p>
            </div>
            <div class="fact">
                <h3>1500+</h3>
                <p>Happy Clients</p>
            </div>
            <div class="fact">
                <h3>5000+</h3>
                <p>Projects Completed</p>
            </div>
        </section>

        <!-- PRICING -->
        <section class="pricing container">
            <div class="section-header">
                <p>WASHING PLAN</p>
                <h2>Choose Your Plan</h2>
            </div>

            <!-- NEW single card wrapper for all plans -->
            <div class="plans-wrapper">
                <div class="plans-card">
                    <div class="price-card">
                        <h3>BASIC CLEANING</h3>
                        <div class="price-big">₹500</div>
                        <ul class="features-list">
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                            <li class="disabled">Window Wiping</li>
                            <li class="disabled">Interior Wet Cleaning</li>
                        </ul>
                        <p><button class="btn" onclick="openBookingModal('Basic Cleaning')">Book Now</button></p>
                    </div>

                    <div class="price-card featured">
                        <h3>PREMIUM CLEANING</h3>
                        <div class="price-big">₹1000</div>
                        <ul class="features-list">
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                            <li>Window Wiping</li>
                            <li class="disabled">Interior Wet Cleaning</li>
                        </ul>
                        <p><button class="btn" onclick="openBookingModal('Premium Cleaning')">Book Now</button></p>
                    </div>

                    <div class="price-card">
                        <h3>COMPLEX CLEANING</h3>
                        <div class="price-big">₹2500</div>
                        <ul class="features-list">
                            <li>Seats Washing</li>
                            <li>Vacuum Cleaning</li>
                            <li>Exterior Cleaning</li>
                            <li>Window Wiping</li>
                            <li>Interior Wet Cleaning</li>
                        </ul>
                        <p><button class="btn" onclick="openBookingModal('Complex Cleaning')">Book Now</button></p>
                    </div>
                </div>
            </div>
        </section>
    </main>

 <!-- Booking Modal -->
<div class="modal-backdrop" id="modal" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true">
    <h4>Car Wash Booking</h4>

    <!-- form action points to Booking.php -->
    <form id="bookingForm" action="main_page.php" method="post">
      <!-- service_type -->
      <div class="form-row">
        <label for="service_type">Select Package</label>
        <select name="service_type" id="service_type" required>
          <option value="">-- Select Package --</option>
          <option value="Basic Cleaning">Option A - Basic Cleaning (₹500)</option>
          <option value="Premium Cleaning">Option B - Premium Cleaning (₹1000)</option>
          <option value="Complex Cleaning">Option C - Complex Cleaning (₹2500)</option>
        </select>
      </div>

      <!-- washing_point_id -->
      <div class="form-row">
        <label for="washing_point_id">Washing Point</label>
        <select name="washing_point_id" id="washing_point_id" required>
          <option value="">-- Select Washing Point --</option>
          <option value="1">Option A - ABC  Car Washing Point (ABC Chokdi, Bharuch)</option>
          <option value="2">Option B - NAB  Car Washing Point (Janor Chokdi, Nabipur)</option>
          <option value="3">Option C - FCB  Car Washing Point (Derol Chokdi, Derol)</option>
        </select>
      </div>

      <!-- vehicle_number -->
      <div class="form-row">
        <label for="vehicle_number">Vehicle Number</label>
        <input type="text" name="vehicle_number" id="vehicle_number" placeholder="Vehicle Number" required>
      </div>

      <!-- vehicle_type -->
      <div class="form-row">
        <label for="vehicle_type">Vehicle Type</label>
        <select name="vehicle_type" id="vehicle_type" required>
          <option value="">-- Select Type --</option>
          <option value="Maruti Suzuki">Maruti Suzuki</option>
<option value="Hyundai">Hyundai</option>
<option value="Tata Motors">Tata Motors</option>
<option value="Mahindra">Mahindra</option>
<option value="Kia">Kia</option>
<option value="Toyota">Toyota</option>
<option value="Honda">Honda</option>
<option value="Skoda">Skoda</option>
<option value="Volkswagen">Volkswagen</option>
<option value="Renault">Renault</option>
<option value="Nissan">Nissan</option>
<option value="MG Motor">MG Motor</option>
<option value="Jeep">Jeep</option>
<option value="Citroën">Citroën</option>
<option value="Mercedes-Benz">Mercedes-Benz</option>
<option value="BMW">BMW</option>
<option value="Audi">Audi</option>
<option value="Volvo">Volvo</option>
<option value="Jaguar">Jaguar</option>
<option value="Land Rover">Land Rover</option>
<option value="Lexus">Lexus</option>
<option value="Porsche">Porsche</option>
<option value="Ferrari">Ferrari</option>
<option value="Lamborghini">Lamborghini</option>
<option value="Maserati">Maserati</option>
<option value="Aston Martin">Aston Martin</option>
<option value="Bentley">Bentley</option>
<option value="Rolls-Royce">Rolls-Royce</option>

        </select>
      </div>

      <!-- wash date -->
      <div class="form-row">
        <label for="Wash_date">Wash Date</label><br>
        <input type="date" name="Wash_date" id="Wash_date" required>
      </div>

      <!-- wash time -->
      <div class="form-row">
        <label for="washtime">Wash Time (optional)</label><br>
        <input type="time" name="Wash_time" id="washtime">
      </div>

      <div class="actions">
        <button type="button" class="btn alt" id="closeModal">Close</button>
        <button type="submit" class="btn">Book Now</button>
      </div>
    </form>
  </div>
</div>


     
    <!-- Footer Start -->
  <footer style="background:#1d2b3a; color:white; padding:40px 0; font-family:'Barlow', sans-serif;">
    <div style="display:flex; justify-content:space-around; flex-wrap:wrap; max-width:1200px; margin:auto;">

      <!-- Get In Touch -->
      <div>
        <h3 style="color:#e63946; margin-bottom:15px;">Get In Touch</h3>
        <br>
        <p>📍 ABC circle, Bharuch - 392012</p>
        <br>
        <p>📞 +91 9558893914</p>
        <p>📞 +91 6354592686</p>
         <br>
        <p>✉ carwash@gmail.com</p>
        <div style="margin-top:15px;">
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733614.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733561.png" width="32"></a>
        </div>
      </div>

      <!-- Popular Links -->
      <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Popular Links</h3>
                <ul style="list-style:none; padding:0; line-height:2;">
                    <li><a href="https://www.speedcarwash.com/terms-and-conditions" style="color:white; text-decoration:none;">› Terms & Conditions</a></li>
                    <li><a href="https://car-washer.in/privacy-policy/" style="color:white; text-decoration:none;">› Privacy Policy</a></li>
                </ul>
            </div>

    </div>

    <!-- Bottom -->
    <div style="text-align:center; margin-top:30px; border-top:1px solid rgba(255,255,255,0.2); padding-top:15px;">
      © 2025 Car Wash | All Rights Reserved
    </div>
  </footer>
  <!-- Footer End -->



     <script>
    // Simple JS slider
    const slides = document.getElementById('slides');
    const total = slides.children.length;
    let index = 0;

    function showSlide(i) {
      index = (i + total) % total;
      slides.style.transform = `translateX(-${index * 100}%)`;
    }

    document.getElementById('next').onclick = () => showSlide(index + 1);
    document.getElementById('prev').onclick = () => showSlide(index - 1);

    // Auto slide
    setInterval(() => showSlide(index + 1), 4000);

    // Booking modal helpers (basic)
    function openBookingModal(pkg) {
      document.getElementById('modal').style.display = 'flex';
      if(pkg) {
        const sel = document.getElementById('packagetype');
        sel.value = pkg;
      }
    }
    document.getElementById('closeModal').onclick = () => {
      document.getElementById('modal').style.display = 'none';
    };
  
  </script>
</body>

</html>
