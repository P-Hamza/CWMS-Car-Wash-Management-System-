<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "car_wash");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$login_error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM admin WHERE email='$username' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        if (isset($row['password']) && password_verify($password, $row['password'])) {
            $_SESSION['admin_email'] = $row['email'];
            header("Location: admin_dashbord.php");
            exit;
        } elseif ($row['password'] === $password) {
            $_SESSION['admin_email'] = $row['email'];
            header("Location: admin_dashbord.php");
            exit;
        } else {
            $login_error = 'Invalid password. Please try again.';
        }
    } else {
        $login_error = 'No account found with that username.';
    }
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Sign In</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    /* --- Clean gradient background design --- */
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family:'Inter',Arial,sans-serif;
      background:linear-gradient(135deg,#3b8fc0,#0b6b88);
      color:#0b2135;
      display:flex;
      align-items:center;
      justify-content:center;
      height:100vh;
      padding:16px;
    }

    .card{
      width:360px;
      background:#ffffff;
      border-radius:10px;
      box-shadow:0 6px 18px rgba(0,0,0,0.15);
      padding:24px 20px;
    }

    h1{
      font-size:20px;
      margin:0 0 10px;
      font-weight:600;
      text-align:center;
      color:#0b6b88;
    }

    p.small{
      margin:0 0 18px;
      color:#6b7a86;
      font-size:13px;
      text-align:center;
    }

    label{
      display:block;
      font-size:13px;
      color:#334155;
      margin-bottom:6px;
    }

    input[type="text"],input[type="password"]{
      width:100%;
      padding:10px 12px;
      border:1px solid #d1d5db;
      border-radius:6px;
      font-size:14px;
      margin-bottom:12px;
      background:#f9fafb;
      color:#0b2135;
      outline:none;
    }

    input:focus{
      border-color:#3b8fc0;
      box-shadow:0 0 0 2px rgba(59,143,192,0.2);
    }

    .btn{
      width:100%;
      padding:10px 12px;
      border-radius:6px;
      border:0;
      background:#0b6b88;
      color:#fff;
      font-weight:600;
      font-size:15px;
      cursor:pointer;
      transition:background 0.2s ease;
    }
    .btn:hover{background:#095b74;}

    .link{
      display:block;
      text-align:center;
      margin-top:12px;
      font-size:13px;
      color:#0b6b88;
      text-decoration:none;
    }
    .link:hover{text-decoration:underline;}

    .error{
      background:#fff5f5;
      border:1px solid #f8d7da;
      color:#b91c1c;
      padding:8px 10px;
      border-radius:6px;
      margin-bottom:12px;
      font-size:13px;
    }

    @media (max-width:400px){
      .card{width:100%;padding:18px;}
    }
  </style>
</head>
<body>

  <div class="card">
    <h1>Admin Sign In</h1>
    <p class="small">Sign in to manage your Car Wash dashboard</p>

    <?php if(!empty($login_error)): ?>
      <div class="error"><?=htmlspecialchars($login_error)?></div>
    <?php endif; ?>

    <form method="post" action="">
      <label for="username">Email</label>
      <input id="username" name="username" type="text" placeholder="Email" required autocomplete="username">

      <label for="password">Password</label>
      <input id="password" name="password" type="password" placeholder="Password" required autocomplete="current-password">

      <input type="submit" class="btn" name="login" value="Sign In">
    </form>

    <a class="link" href="..\index.php">⬅ Back to Home</a>
  </div>

</body>
</html>
