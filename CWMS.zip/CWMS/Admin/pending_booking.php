<?php
// new_booking.php
// Show bookings with status = Accept, allow marking as Complete

// --- CONFIG ---
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'car_wash');
$tableName = 'booking';
// ---------------

// connect
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("DB connection failed: " . htmlspecialchars($conn->connect_error));
}

/* Handle POST (Complete action) */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($booking_id > 0 && $action === 'Complete') {
        $stmt = $conn->prepare("UPDATE `{$tableName}` SET `status` = ? WHERE `booking_id` = ?");
        if ($stmt) {
            $stmt->bind_param('si', $action, $booking_id);
            $ok = $stmt->execute();
            $stmt->close();

            if ($ok) {
                header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode("Booking #{$booking_id} marked as Complete."));
                exit;
            } else {
                header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode("Failed to update booking."));
                exit;
            }
        }
    } else {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode('Invalid request.'));
        exit;
    }
}

/* Fetch only bookings with status = Accept */
$sql = "SELECT `booking_id`, `user_email`, `washing_point_id`, `service_type`, 
               `vehicle_number`, `vehicle_type`, `Wash_date`, `Wash_time`, `status`
        FROM `{$tableName}`
        WHERE LOWER(`status`) = 'accept'
        ORDER BY `booking_id`";
$result = $conn->query($sql);

$msg = '';
if (!empty($_GET['msg'])) $msg = htmlspecialchars($_GET['msg']);
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Accepted Bookings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script>
        function confirmSubmit(form) {
            if (confirm("Are you sure you want to mark this booking as Complete?")) {
                form.submit();
            }
        }
    </script>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>CWMS</h2>
         <ul>
            <li><a href="admin_dashbord.php"><i class="fa-solid fa-house"></i><span> Dashboard</span></a></li>
            <li><a href="washing_point.php"><i class="fa-solid fa-car"></i><span> Washing Points</span></a></li>
            <li><a href="admin_complaint.php"><i class="fa-solid fa-list-check"></i><span> Manage Enquiries</span></a></li>
            <li><a href="..\index.php"><i class="fa-solid fa-right-from-bracket"></i><span> Log Out</span></a></li>
        </ul>
    </div>

    <div class="main">
        <div class="header">
            <div class="header-title">CAR WASH MANAGEMENT SYSTEM</div>
            <div class="user-info">
                <span class="profile-icon">👤</span>
                <div>
                    <h4>
                        <div class="welcome-text">Welcome</div>
                        <div>Administrator</div>
                    </h4>
                </div>
            </div>
        </div>

        <div class="breadcrumbs">
            <h2>
                <a href="admin_dashbord.php">Home</a> &gt; Manage Accepted Bookings
            </h2>
        </div>

        <div class="content">
            <div class="content-header">
                Accepted Bookings
            </div>

            <?php if ($msg): ?>
                <div style="padding:10px; background:#dff0d8; color:#3c763d; margin-bottom:15px;">
                    <?php echo $msg; ?>
                </div>
            <?php endif; ?>

            <div class="table-container">
                <table class="bookings-table">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>User ID</th>
                            <th>Washing Point ID</th>
                            <th>Service Type</th>
                            <th>Vehicle Number</th>
                            <th>Vehicle Type</th>
                            <th>Wash Date</th>
                            <th>Wash Time</th>
                            <th>Current Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0):
                            while ($row = $result->fetch_assoc()):
                                $booking_id = (int)$row['booking_id'];
                        ?>
                                <tr>
                                    <td data-label="Booking ID"><?php echo htmlspecialchars($booking_id); ?></td>
                                    <td data-label="User ID"><?php echo htmlspecialchars($row['user_email']); ?></td>
                                    <td data-label="Washing Point ID"><?php echo htmlspecialchars($row['washing_point_id']); ?></td>
                                    <td data-label="Service Type"><?php echo htmlspecialchars($row['service_type']); ?></td>
                                    <td data-label="Vehicle Number"><?php echo htmlspecialchars($row['vehicle_number']); ?></td>
                                    <td data-label="Vehicle Type"><?php echo htmlspecialchars($row['vehicle_type']); ?></td>
                                    <td data-label="Wash Date"><?php echo htmlspecialchars($row['Wash_date']); ?></td>
                                    <td data-label="Wash Time"><?php echo htmlspecialchars($row['Wash_time']); ?></td>
                                    <td data-label="Current Status"><?php echo htmlspecialchars($row['status']); ?></td>
                                    <td data-label="Actions">
                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display:inline;">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                                            <input type="hidden" name="action" value="Complete">
                                            <button type="button" class="btn btn-accept" onclick="confirmSubmit(this.form)">Complete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile;
                        else: ?>
                            <tr>
                                <td colspan="10" style="text-align:center; padding:18px;">No accepted bookings found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php $conn->close(); ?>
</body>

</html>