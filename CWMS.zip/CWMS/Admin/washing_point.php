<?php
// db connect
$host = "localhost";
$user = "root";
$pass = "";
$db = "car_wash";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("DB Connection Failed: " . $conn->connect_error);
}

// ---------------- Insert New Washing Point ----------------
if (isset($_POST['add_point'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $address = $conn->real_escape_string($_POST['address']);
    $contact = $conn->real_escape_string($_POST['contact']);

    $sql = "INSERT INTO washing_point (name, address, contact_number) 
            VALUES ('$name', '$address', '$contact')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Washing Point Added Successfully!'); window.location='washing_point.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    $conn->query("DELETE FROM booking WHERE washing_point_id=$id");
    $conn->query("DELETE FROM admin WHERE washing_point_id=$id");
    $conn->query("DELETE FROM washing_point WHERE washing_point_id=$id");

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// update request
if (isset($_POST['update'])) {
    $id = intval($_POST['washing_point_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $address = $conn->real_escape_string($_POST['address']);
    $contact = $conn->real_escape_string($_POST['contact_number']);

    $sql = "UPDATE washing_point SET 
                name='$name', 
                address='$address', 
                contact_number='$contact' 
            WHERE washing_point_id=$id";
    $conn->query($sql);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// fetch data
$result = $conn->query("SELECT * FROM washing_point ORDER BY washing_point_id ASC");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Washing Points</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            margin: 0;
        }

        .main-container {
            width: 95%;
            max-width: 1200px;
            margin: 20px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .header {
            font-size: 1.5em;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-add {
            padding: 8px 15px;
            background: #fff;
            color: #28a745;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-add:hover {
            background: green;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #dc3545;
            color: #fff;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background: #f9f9f9;
        }

        tr:hover {
            background: #f1f1f1;
        }

        a.edit {
            color: #007bff;
            cursor: pointer;
        }

        a.delete {
            color: #dc3545;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
        }

        .modal-content h2 {
            margin-top: 0;
        }

        .modal-content label {
            display: block;
            margin: 10px 0 5px;
        }

        .modal-content input,
        .modal-content textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .modal-content button {
            margin-top: 15px;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-cancel {
            background: #6c757d;
            color: #fff;
            margin-right: 10px;
        }

        .btn-update {
            background: #28a745;
            color: #fff;
        }
    </style>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>CWMS</h2>
          <ul>
            <li><a href="admin_dashbord.php"><i class="fa-solid fa-house"></i><span> Dashboard</span></a></li>
            <li><a href="washing_point.php"><i class="fa-solid fa-car"></i><span> Washing Points</span></a></li>
            <li><a href="admin_complaint.php"><i class="fa-solid fa-list-check"></i><span> Manage Enquiries</span></a></li>
            <li><a href="..\index.php"><i class="fa-solid fa-right-from-bracket"></i><span> Log Out</span></a></li>
        </ul>
    </div>

     <div class="main">
        <div class=" header">
            <div class="header-title">CAR WASH MANAGEMENT SYSTEM</div>
            <div class="user-info">
                <span class="profile-icon">👤</span>
                <div>
                    <h4>
                        <div class="welcome-text">Welcome</div>
                        <div>Administrator</div>
                    </h4>
                </div>
            </div>
        </div>



        <div class="breadcrumbs">
            <h3>
                <a href="admin_dashbord.php">Home</a> &gt; Manage Washing Points
            </h3>
        </div>

        <div class="header">
            <span>Manage Car Washing Points</span>
            <button class="btn-add" onclick="openAddModal()">Add Washing Point</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Washing Point Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['washing_point_id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= nl2br(htmlspecialchars($row['address'])) ?></td>
                        <td><?= htmlspecialchars($row['contact_number']) ?></td>
                        <td>
                            <a class="edit"
                                onclick="openEditModal(<?= $row['washing_point_id'] ?>,
                        '<?= htmlspecialchars($row['name'], ENT_QUOTES) ?>',
                        '<?= htmlspecialchars($row['address'], ENT_QUOTES) ?>',
                        '<?= htmlspecialchars($row['contact_number'], ENT_QUOTES) ?>')">Edit</a> |
                            <a class="delete" href="?delete=<?= $row['washing_point_id'] ?>" onclick="return confirm('⚠ Warning: इस Washing Point को delete करने पर related bookings और admin records भी delete हो जाएंगे।\n\nक्या आप सच में delete करना चाहते हैं?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Modal -->
    <div class="modal" id="editModal">
        <div class="modal-content">
            <h2>Edit Washing Point</h2>
            <form method="post">
                <input type="hidden" name="washing_point_id" id="edit_id">
                <label>Name:</label>
                <input type="text" name="name" id="edit_name" required>
                <label>Address:</label>
                <textarea name="address" id="edit_address" rows="3" required></textarea>
                <label>Contact Number:</label>
                <input type="text" name="contact_number" id="edit_contact" required>
                <div style="margin-top:10px;">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" name="update" class="btn-update">Update</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Modal -->
    <div class="modal" id="addModal">
        <div class="modal-content">
            <h2>Add Washing Point</h2>
            <form method="post">
                <label>Name:</label>
                <input type="text" name="name" required>
                <label>Address:</label>
                <textarea name="address" rows="3" required></textarea>
                <label>Contact Number:</label>
                <input type="text" name="contact" required>
                <div style="margin-top:10px;">
                    <button type="button" class="btn-cancel" onclick="closeAddModal()">Cancel</button>
                    <button type="submit" name="add_point" class="btn-update">Insert</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(id, name, address, contact) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_address').value = address;
            document.getElementById('edit_contact').value = contact;
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function openAddModal() {
            document.getElementById('addModal').style.display = 'flex';
        }

        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }
    </script>

</body>

</html>