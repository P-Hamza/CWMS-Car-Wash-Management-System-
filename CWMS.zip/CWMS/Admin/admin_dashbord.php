<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Wash Management System | Admin Dashboard</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>CWMS</h2>
        <ul>
            <li><a href="admin_dashbord.php"><i class="fa-solid fa-house"></i><span> Dashboard</span></a></li>
            <li><a href="washing_point.php"><i class="fa-solid fa-car"></i><span> Washing Points</span></a></li>
            <li><a href="admin_complaint.php"><i class="fa-solid fa-list-check"></i><span> Manage Enquiries</span></a></li>
            <li><a href="..\index.php"><i class="fa-solid fa-right-from-bracket"></i><span> Log Out</span></a></li>
        </ul>
    </div>

    <!-- Main -->
    <div class="main">
        <div class="topbar">
            <h1>Car Wash Management System</h1>
            <div class="user-info">
                <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png" alt="Admin">
                <span>Welcome, Admin</span>
            </div>
        </div>

        <!-- Cards -->
        <div class="cards">
            <a class="card total" href="complete_booking.php">
                <i class="fa fa-calendar-check"></i>
                <h3>Complete Bookings</h3>
            </a>
            <a class="card new" href="pending_booking.php">
                <i class="fa fa-clock"></i>
                <h3>Pending Bookings</h3>
            </a>
            <a class="card completed" href="new_booking.php">
                <i class="fa fa-check-circle"></i>
                <h3>New Booking</h3>
            </a>
            <a class="card enquiries" href="admin_complaint.php">
                <i class="fa fa-envelope"></i>
                <h3>Complaint</h3>
            </a>
        </div>

        <footer>© 2025 CWMS. All Rights Reserved.</footer>
    </div>
</body>

</html>