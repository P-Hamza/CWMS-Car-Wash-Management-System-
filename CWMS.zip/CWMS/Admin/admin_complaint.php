<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_wash";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle "Take Action" click (update status)
if (isset($_GET['action_id'])) {
    $id = intval($_GET['action_id']);
    $conn->query("UPDATE complaints SET status='Complete' WHERE complaint_id=$id");
    // Redirect back to the table page without GET parameter
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch complaints
$sql = "SELECT * FROM complaints";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Complaints Table</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
     <!-- Sidebar -->
    <div class="sidebar">
        <h2>CWMS</h2>
          <ul>
            <li><a href="admin_dashbord.php"><i class="fa-solid fa-house"></i><span> Dashboard</span></a></li>
            <li><a href="washing_point.php"><i class="fa-solid fa-car"></i><span> Washing Points</span></a></li>
            <li><a href="admin_complaint.php"><i class="fa-solid fa-list-check"></i><span> Manage Enquiries</span></a></li>
            <li><a href="..\index.php"><i class="fa-solid fa-right-from-bracket"></i><span> Log Out</span></a></li>
        </ul>
    </div>

   
    <div class="main">
        <div class=" header">
            <div class="header-title">CAR WASH MANAGEMENT SYSTEM</div>
            <div class="user-info">
                <span class="profile-icon">👤</span>
                <div>
                    <h4>
                        <div class="welcome-text">Welcome</div>
                        <div>Administrator</div>
                    </h4>
                </div>
            </div>
        </div>



        <div class="breadcrumbs">
            <h2>
                <a href="admin_dashbord.php">Home</a> &gt; Manage Complation
            </h2>
        </div>

        <div class="content">
            <div class="content-header">
                Completed Bookings
            </div>

            <div class="table-container">
                <table class="bookings-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Subject</th>
                <th>Description</th>
                <th>Status</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $email_encoded = urlencode($row['email']);
                    $status_class = strtolower($row['status']);
                    echo "<tr>
                <td>{$row['complaint_id']}</td>
                <td>{$row['user_id']}</td>
                <td>{$row['subject']}</td>
                <td>{$row['description']}</td>
                <td class='{$status_class}'>{$row['status']}</td>
                <td>{$row['email']}</td>
               <td>
    <a class='action-btn' target='_blank' 
       href='https://mail.google.com/mail/u/0/?view=cm&fs=1&to={$email_encoded}'>
       Take Action
    </a>
    &nbsp;
    <a class='action-btn' style='background:#ffc107; color:#000;' 
       href='?action_id={$row['complaint_id']}'>
       Mark Complete
    </a>
</td>

            </tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align:center;'>No complaints found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>

</html>
<?php $conn->close(); ?>