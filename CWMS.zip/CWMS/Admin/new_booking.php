<?php
// new_booking.php
// Single-file: show pending bookings and allow Accept / Reject (updates status column)

// --- CONFIG: change if needed ---
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'car_wash');
$tableName = 'booking'; // as you said
// -------------------------------

// connect
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("DB connection failed: " . htmlspecialchars($conn->connect_error));
}

/* Handle POST (Accept / Reject) */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($booking_id <= 0 || !in_array($action, ['Accept', 'Reject'])) {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode('Invalid request.'));
        exit;
    }

    // update status to Accept or Reject (exact strings as requested)
    $stmt = $conn->prepare("UPDATE `{$tableName}` SET `status` = ? WHERE `booking_id` = ?");
    if (!$stmt) {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode('Prepare failed.'));
        exit;
    }
    $stmt->bind_param('si', $action, $booking_id);
    $ok = $stmt->execute();
    $stmt->close();

    if ($ok) {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode("Booking #{$booking_id} marked as {$action}."));
        exit;
    } else {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode("Failed to update booking."));
        exit;
    }
}

/* Fetch only pending bookings (status = Pending) */
$sql = "SELECT `booking_id`, `user_email`, `washing_point_id`, `service_type`, `vehicle_number`, `vehicle_type`, `Wash_date`, `Wash_time`, `status`
        FROM `{$tableName}`
        WHERE LOWER(`status`) = 'pending'
        ORDER BY `booking_id`";
$result = $conn->query($sql);

$msg = '';
if (!empty($_GET['msg'])) $msg = htmlspecialchars($_GET['msg']);
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Pending Bookings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">

    <script>
        function confirmAndSubmit(form, actionText) {
            if (confirm("Confirm " + actionText + " for this booking?")) {
                form.submit();
            }
        }
    </script>
</head>

<body>

  <!-- Sidebar -->
    <div class="sidebar">
        <h2>CWMS</h2>
          <ul>
            <li><a href="admin_dashbord.php"><i class="fa-solid fa-house"></i><span> Dashboard</span></a></li>
            <li><a href="washing_point.php"><i class="fa-solid fa-car"></i><span> Washing Points</span></a></li>
            <li><a href="admin_complaint.php"><i class="fa-solid fa-list-check"></i><span> Manage Enquiries</span></a></li>
            <li><a href="..\index.php"><i class="fa-solid fa-right-from-bracket"></i><span> Log Out</span></a></li>
        </ul>
    </div>

    <div class="main">
    <div class="header">
        <div class="header-title">CAR WASH MANAGEMENT SYSTEM</div>
        <div class="user-info">
            <span class="profile-icon">👤</span>
            <div>
                <h4>
                <div class="welcome-text">Welcome</div>
                <div>Administrator</div>
                    </h4>
            </div>
        </div>
    </div>

     <div class="breadcrumbs">
        <h2>
        <a href="admin_dashbord.php">Home</a> &gt; Manage New Bookings </h2>
    </div>

    <div class="content">
        <div class="content-header">
            New Bookings
        </div>

             <div class="table-container">
            <table class="bookings-table">
             <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>User ID</th>
                        <th>Washing Point ID</th>
                        <th>Service Type</th>
                        <th>Vehicle Number</th>
                        <th>Vehicle Type</th>
                        <th>Wash Date</th>
                        <th>Wash Time</th>
                        <th>Current Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0):
                        $i = 0;
                        while ($row = $result->fetch_assoc()):
                            $i++;
                            $booking_id = (int)$row['booking_id'];
                    ?>
                            <tr>
                               
                                <td data-label="Booking ID"><?php echo htmlspecialchars($booking_id); ?></td>
                                <td data-label="User ID"><?php echo htmlspecialchars($row['user_email']); ?></td>
                                <td data-label="Washing Point ID"><?php echo htmlspecialchars($row['washing_point_id']); ?></td>
                                <td data-label="Service Type"><?php echo htmlspecialchars($row['service_type']); ?></td>
                                <td data-label="Vehicle Number"><?php echo htmlspecialchars($row['vehicle_number']); ?></td>
                                <td data-label="Vehicle Type"><?php echo htmlspecialchars($row['vehicle_type']); ?></td>
                                <td data-label="Wash Date"><?php echo htmlspecialchars($row['Wash_date']); ?></td>
                                <td data-label="Wash Time"><?php echo htmlspecialchars($row['Wash_time']); ?></td>
                                <td data-label="Current Status"><?php echo htmlspecialchars($row['status']); ?></td>
                                <td data-label="Actions">
                                    <div class="actions">
                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display:inline;">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                                            <input type="hidden" name="action" value="Accept">
                                            <button type="button" class="btn btn-accept" onclick="confirmAndSubmit(this.form, 'Accept')">Accept</button>
                                        </form>

                                        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display:inline;">
                                            <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                                            <input type="hidden" name="action" value="Reject">
                                            <button type="button" class="btn btn-reject" onclick="confirmAndSubmit(this.form, 'Reject')">Reject</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php
                        endwhile;
                    else:
                        ?>
                        <tr>
                            <td colspan="11" style="text-align:center; padding:18px;">No pending bookings found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    </div>
    <?php
    $conn->close();
    ?>
</body>

</html>