<?php
// ====================
// complaint.php
// ====================

// 1️⃣ Start session at top
session_start();

// 2️⃣ DB connection
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';          // agar password hai to yaha daldo
$DB_NAME = 'car_wash';    // replace with your actual database name

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// 3️⃣ Handle POST form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // sanitize & collect
    $name    = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email   = isset($_POST['email']) ? trim($_POST['email']) : '';
    $subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';

    // validation
    if ($name === '' || $email === '' || $subject === '' || $message === '') {
        echo "<script>alert('Please fill all required fields.'); window.history.back();</script>";
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Please enter a valid email address.'); window.history.back();</script>";
        exit;
    }

    // user_id from session, default 0 for guest
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
    $status = 'Pending';

    // insert into table
    $stmt = $conn->prepare("INSERT INTO complaints (user_id, subject, description, status, email) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $user_id, $subject, $message, $status, $email);

    if ($stmt->execute()) {
        $stmt->close();
        echo "<script>
                alert('Your complaint successfully registered. We will contact you via email within 24 hours.');
                window.location = 'complaint.php';
              </script>";
        exit;
    } else {
        $stmt->close();
        echo "<script>alert('Error submitting complaint. Please try again later.'); window.history.back();</script>";
        exit;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link rel="stylesheet" href="style.css"> 
</head>
<body>
     <!-- TOP BAR -->
   <div class="topbar" id="topbar">
        <div class="inner">
            <div class="logo"><span style="color:var(--accent)">CAR</span><span class="dark">Wash</span></div>
            <div class="top-info">
                <div class="item"><strong>Opening Hour</strong><small>⏰  Mon - Sat: 8:00 AM - 9:00 PM</small></div>
                <div class="item"><strong>Call Us</strong><small> 📞 +91 9558893914</small></div>
                <div class="item"><strong>Email</strong><small> ✉ carwash@gmail.com</small></div>
            </div>
        </div>
    </div>

    <!-- NAV BAR -->
    <div class="nav-bar" id="navBar">
        <div class="nav-inner">
            <ul class="nav-links" role="navigation" aria-label="Main Nav">
             <li><a href="main_page.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="plans.php">WASHING PLANS</a></li>
                <li><a href="points.php">WASHING POINTS</a></li>
                <li><a href="complaint.php">COMPLAINT</a></li>
                <li><a href="appoinment.php">APPOINMENT</a></li>
            </ul>
        </div>
    </div>

    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Complaint</h2>
                </div>
                </div>
            </div>
        </div>
    </div>

     <!-- Main Content -->
    <section class="main-section">

        <!-- Contact Info Box -->
        <div class="contact-info">
            <h3>Quick Contact Info</h3>
            <div class="contact-item">
                <div class="contact-icon">📍</div>
                <div class="contact-text">
                    <strong>Address</strong>
                    <span>ABC circle ,Bharuch - 392012</span>
                </div>
            </div>
            <div class="contact-item">
                <div class="contact-icon">⏰</div>
                <div class="contact-text">
                    <strong>Opening Hour</strong>
                    <span>Mon - Sat, 8:00 AM - 9:00 PM</span>
                </div>
            </div>
            <div class="contact-item">
                <div class="contact-icon">📞</div>
                <div class="contact-text">
                    <strong>Call Us</strong>
                    <span>+91 9558893914</span>
                </div>
            </div>
            <div class="contact-item">
                <div class="contact-icon">✉️</div>
                <div class="contact-text">
                    <strong>Email Us</strong>
                    <span>carwash@gmail.com</span>
                </div>
            </div>
        </div>

        <!-- Contact Form -->
<section class="main-section">
    <form class="contact-form" action="complaint.php" method="POST">
        <p class="small-heading">GET IN TOUCH</p>
        <h2>Contact For Any Query</h2>
        <input type="text" name="name" placeholder="Your Name" required />
        <input type="email" name="email" placeholder="Your Email" required />
        <input type="text" name="subject" placeholder="Subject" required />
        <textarea name="message" placeholder="Message" required></textarea>
        <button type="submit">Send Message</button>
    </form>
</section>

    </section>

     <!-- Footer Start -->
  <footer style="background:#1d2b3a; color:white; padding:40px 0; font-family:'Barlow', sans-serif;">
    <div style="display:flex; justify-content:space-around; flex-wrap:wrap; max-width:1200px; margin:auto;">

      <!-- Get In Touch -->
      <div>
        <h3 style="color:#e63946; margin-bottom:15px;">Get In Touch</h3>
        <br>
        <p>📍  ABC circle, Bharuch - 392012</p>
        <br>
        <p>📞 +91 9558893914</p>
        <p>📞 +91 6354592686</p>
         <br>
        <p>✉ carwash@gmail.com</p>
        <div style="margin-top:15px;">
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733614.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733561.png" width="32"></a>
        </div>
      </div>

      <!-- Popular Links -->
      <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Popular Links</h3>
                <ul style="list-style:none; padding:0; line-height:2;">
                    <li><a href="https://www.speedcarwash.com/terms-and-conditions" style="color:white; text-decoration:none;">› Terms & Conditions</a></li>
                    <li><a href="https://car-washer.in/privacy-policy/" style="color:white; text-decoration:none;">› Privacy Policy</a></li>
                </ul>
            </div>

    </div>

    <!-- Bottom -->
    <div style="text-align:center; margin-top:30px; border-top:1px solid rgba(255,255,255,0.2); padding-top:15px;">
       © 2025 Car Wash | All Rights Reserved
    </div>
  </footer>
  <!-- Footer End -->
   
</body>
</html>