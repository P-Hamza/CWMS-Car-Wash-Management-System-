<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Car Wash management System | About Us Page</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Required CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
      <link rel="stylesheet" href="style.css">
  
</head>

<body>
    <!-- Top Header Start -->
    <div class="top-bar">
        <div class="container">
            <div class="row align-items-center w-100">
                <div class="col-lg-6 col-md-12">
                    <div class="top-bar-left d-flex align-items-center">
                        <div class="text">
                            <i class="far fa-clock"></i>
                            <h2>8:00am - 9:00pm</h2>
                            <p>Mon - Sat</p>
                        </div>
                        <div class="text">
                            <i class="fa fa-phone-alt"></i>
                            <h2>+91 9558839314</h2> <br/>
                            <h2>+91 6354592686</h2>

                            <p>Call Us For Booking</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-7 d-none d-lg-block">
                    <div class="top-bar-right d-flex justify-content-end align-items-center">
                        <div class="text">
                            <i class="fa fa-envelope"></i>
                            <h2>carwash@gmail.com</h2>
                            <p>Email Us</p>
                        </div>
                        <div class="social">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Header -->
    <div class="nav-bar">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                <div class="logo"><span style="color:var(--accent)">CAR</span><span class="dark">Wash</span></div>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <!-- Left side can remain empty or put links here if needed -->
                    <div></div>

                    <!-- New buttons on right -->
                    <div class="nav-actions">
                        <a class="btn" id="openBooking" href="login.php" class="nav-btn">Login</a>
                        <a class="btn" id="openBooking" href="Register.php" class="nav-btn">Signup</a>
                        <a class="btn" id="openBooking" href="Admin/admin_login.php" class="nav-btn">Admin</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>About Us</h2>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- About Start -->
    <div class="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-img">
                        <img src="img/about.jpg" alt="Image">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="section-header text-left">
                        <p>About Us</p>
                        <h2>Car Washing and Detailing</h2>
                    </div>
                    <div class="about-content">
                        <p>
                            Welcome to our Car Wash Management System.  
                            We provide top quality car washing and detailing services 
                            to keep your vehicle clean, shiny, and fresh.  
                            Our professional team ensures customer satisfaction with every wash.
                        </p>
                        <hr />
                        <ul>
                            <li><i class="far fa-check-circle"></i>Seats Washing</li>
                            <li><i class="far fa-check-circle"></i>Vacuum Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Interior Wet Cleaning</li>
                            <li><i class="far fa-check-circle"></i>Window Wiping</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

     <!-- Footer Start -->
  <footer style="background:#1d2b3a; color:white; padding:40px 0; font-family:'Barlow', sans-serif;">
    <div style="display:flex; justify-content:space-around; flex-wrap:wrap; max-width:1200px; margin:auto;">

      <!-- Get In Touch -->
      <div>
        <h3 style="color:#e63946; margin-bottom:15px;">Get In Touch</h3>
        <br>
        <p>📍 ABC circle, Bharuch - 392012</p>
        <br>
        <p>📞 +91 9558893914</p>
        <p>📞 +91 6354592686</p>
         <br>
        <p>✉ carwash@gmail.com</p>
        <div style="margin-top:15px;">
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733614.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733561.png" width="32"></a>
        </div>
      </div>

      <!-- Popular Links -->
      <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Popular Links</h3>
                <ul style="list-style:none; padding:0; line-height:2;">
                    <li><a href="https://www.speedcarwash.com/terms-and-conditions" style="color:white; text-decoration:none;">› Terms & Conditions</a></li>
                    <li><a href="https://car-washer.in/privacy-policy/" style="color:white; text-decoration:none;">› Privacy Policy</a></li>
                </ul>
            </div>

    </div>

    <!-- Bottom -->
    <div style="text-align:center; margin-top:30px; border-top:1px solid rgba(255,255,255,0.2); padding-top:15px;">
       © 2025 Car Wash | All Rights Reserved
    </div>
  </footer>
  <!-- Footer End -->

    <!-- Required JS Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
</body>
</html>
