<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link rel="stylesheet" href="style.css"> 
</head>
<body>
     <!-- TOP BAR -->
   <div class="topbar" id="topbar">
        <div class="inner">
            <div class="logo"><span style="color:var(--accent)">CAR</span><span class="dark">Wash</span></div>
            <div class="top-info">
                <div class="item"><strong>Opening Hour</strong><small>⏰  Mon - Sat: 8:00 AM - 9:00 PM</small></div>
                <div class="item"><strong>Call Us</strong><small> 📞 +91 9558893914</small></div>
                <div class="item"><strong>Email</strong><small> ✉ carwash@gmail.com</small></div>
            </div>
        </div>
    </div>

    <!-- NAV BAR -->
    <div class="nav-bar" id="navBar">
        <div class="nav-inner">
            <ul class="nav-links" role="navigation" aria-label="Main Nav">
                <li><a href="main_page.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="plans.php">WASHING PLANS</a></li>
                <li><a href="points.php">WASHING POINTS</a></li>
                <li><a href="complaint.php">COMPLAINT</a></li>
                <li><a href="appoinment.php">APPOINMENT</a></li>
            </ul>
        </div>
    </div>

    
    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Washing Plans</h2>
                </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Plans Section -->
    <section class="plans-section">
        <p class="small-heading">WASHING PLAN</p>
        <h2>Choose Your Plan</h2>
        <div class="plans-container">
            <!-- Basic Cleaning -->
            <div class="plan-card highlight">
                <p class="plan-type">BASIC CLEANING</p>
                <p class="price">₹500</p>
                <ul class="features-list">
                    <li>Seats Washing</li>
                    <li>Vacuum Cleaning</li>
                    <li>Exterior Cleaning</li>
                    <li class="disabled">Interior Wet Cleaning</li>
                    <li class="disabled">Window Wiping</li>
                </ul>
                <button class="book-btn">Book From Home Page</button>
            </div>

            <!-- Premium Cleaning -->
            <div class="plan-card highlight">
                <p class="plan-type">PREMIUM CLEANING</p>
                <p class="price">₹1000</p>
                <ul class="features-list">
                    <li>Seats Washing</li>
                    <li>Vacuum Cleaning</li>
                    <li>Exterior Cleaning</li>
                    <li>Interior Wet Cleaning</li>
                    <li class="disabled">Window Wiping</li>
                </ul>
                <button class="book-btn">Book From Home Page</button>
            </div>

            <!-- Complex Cleaning -->
            <div class="plan-card highlight">
                <p class="plan-type">COMPLEX CLEANING</p>
                <p class="price">₹2500</p>
                <ul class="features-list">
                    <li>Seats Washing</li>
                    <li>Vacuum Cleaning</li>
                    <li>Exterior Cleaning</li>
                    <li>Interior Wet Cleaning</li>
                    <li>Window Wiping</li>
                </ul>
                <button class="book-btn">Book From Home Page</button>
            </div>
        </div>
    </section>

     <!-- Footer Start -->
  <footer style="background:#1d2b3a; color:white; padding:40px 0; font-family:'Barlow', sans-serif;">
    <div style="display:flex; justify-content:space-around; flex-wrap:wrap; max-width:1200px; margin:auto;">

      <!-- Get In Touch -->
      <div>
        <h3 style="color:#e63946; margin-bottom:15px;">Get In Touch</h3>
        <br>
        <p>📍  ABC circle, Bharuch - 392012</p>
        <br>
        <p>📞 +91 9558893914</p>
        <p>📞 +91 6354592686</p>
         <br>
        <p>✉ carwash@gmail.com</p>
        <div style="margin-top:15px;">
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733614.png" width="32" style="margin-right:8px;"></a>
          <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733561.png" width="32"></a>
        </div>
      </div>

      <!-- Popular Links -->
     <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Popular Links</h3>
                <ul style="list-style:none; padding:0; line-height:2;">
                    <li><a href="https://www.speedcarwash.com/terms-and-conditions" style="color:white; text-decoration:none;">› Terms & Conditions</a></li>
                    <li><a href="https://car-washer.in/privacy-policy/" style="color:white; text-decoration:none;">› Privacy Policy</a></li>
                </ul>
            </div>

    </div>

    <!-- Bottom -->
    <div style="text-align:center; margin-top:30px; border-top:1px solid rgba(255,255,255,0.2); padding-top:15px;">
       © 2025 Car Wash | All Rights Reserved
    </div>
  </footer>
  <!-- Footer End -->
   
</body>
</html>