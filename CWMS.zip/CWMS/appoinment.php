<?php
session_start();
include 'config.php';

// get user email from cookie
$user_email = isset($_COOKIE['user_email']) ? trim($_COOKIE['user_email']) : '';
if (!$user_email) {
    echo "<h2>Please login to see your bookings.</h2><a href='login.php'>Login</a>";
    exit;
}

// fetch bookings where booking.user_email matches
$sql = "SELECT booking_id, washing_point_id, service_type, vehicle_number, vehicle_type, Wash_date, Wash_time, status
        FROM booking
        WHERE user_email = ?
        ORDER BY booking_id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$bookings = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings</title>
    <link rel="stylesheet" href="style.css"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f6f8fb;
            padding: 0;
            margin: 0;
            color: #0a2a43;
        }

        .card {
            max-width: 1000px;
            margin: 40px auto;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #f0f4f8;
        }

        tr:hover {
            background: #f1faff;
        }

        .status {
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 13px;
            display: inline-block;
        }

        .status-Pending {
            background: #fff4e6;
            color: #b45b00;
            border: 1px solid #ffe6cc;
        }

        .status-Accept {
            background: #e6fff0;
            color: #166a2a;
            border: 1px solid #c4f0d2;
        }

        .status-Reject {
            background: #fff0f0;
            color: #8a1f1f;
            border: 1px solid #ffd6d6;
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>

<body>

    <!-- TOP BAR -->
    <div class="topbar" id="topbar">
        <div class="inner">
            <div class="logo"><span style="color:var(--accent)">CAR</span><span class="dark">Wash</span></div>
            <div class="top-info">
                <div class="item"><strong>Opening Hour</strong><small>⏰ Mon - Sat: 8:00 AM - 9:00 PM</small></div>
                <div class="item"><strong>Call Us</strong><small> 📞 +91 9558893914</small></div>
                <div class="item"><strong>Email</strong><small> ✉ carwash@gmail.com</small></div>
            </div>
        </div>
    </div>

    <!-- NAV BAR -->
    <div class="nav-bar" id="navBar">
        <div class="nav-inner">
            <ul class="nav-links" role="navigation" aria-label="Main Nav">
                <li><a href="main_page.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="plans.php">WASHING PLANS</a></li>
                <li><a href="points.php">WASHING POINTS</a></li>
                <li><a href="complaint.php">COMPLAINT</a></li>
                <li><a href="appoinment.php">APPOINTMENT</a></li>
            </ul>
        </div>
    </div>

    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Appointment Details</h2>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <h1>My Bookings</h1>
        <p>Showing bookings for: <strong><?php echo htmlspecialchars($user_email); ?></strong></p>
        <?php if (count($bookings) === 0): ?>
            <div class="no-data">No bookings yet...</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Washing Point</th>
                        <th>Service</th>
                        <th>Vehicle No.</th>
                        <th>Vehicle Type</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $b):
                        $statusClass = 'status-' . htmlspecialchars($b['status']);
                    ?>
                        <tr>
                            <td><?php echo $b['booking_id']; ?></td>
                            <td><?php echo htmlspecialchars($b['washing_point_id']); ?></td>
                            <td><?php echo htmlspecialchars($b['service_type']); ?></td>
                            <td><?php echo htmlspecialchars($b['vehicle_number']); ?></td>
                            <td><?php echo htmlspecialchars($b['vehicle_type']); ?></td>
                            <td><?php echo htmlspecialchars($b['Wash_date']); ?></td>
                            <td><?php echo htmlspecialchars($b['Wash_time']); ?></td>
                            <td><span class="status <?php echo $statusClass; ?>"><?php echo htmlspecialchars($b['status']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Footer Start -->
    <footer style="background:#1d2b3a; color:white; padding:40px 0; font-family:'Barlow', sans-serif;">
        <div style="display:flex; justify-content:space-around; flex-wrap:wrap; max-width:1200px; margin:auto;">

            <!-- Get In Touch -->
            <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Get In Touch</h3>
                <br>
                <p>📍 ABC circle, Bharuch - 392012</p>
                <br>
                <p>📞 +91 9558893914</p>
                <p>📞 +91 6354592686</p>
                <br>
                <p>✉ carwash@gmail.com</p>
                <div style="margin-top:15px;">
                    <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="32" style="margin-right:8px;"></a>
                    <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="32" style="margin-right:8px;"></a>
                    <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733558.png" width="32" style="margin-right:8px;"></a>
                    <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733614.png" width="32" style="margin-right:8px;"></a>
                    <a href="#"><img src="https://cdn-icons-png.flaticon.com/512/733/733561.png" width="32"></a>
                </div>
            </div>

            <!-- Legal Links -->
            <div>
                <h3 style="color:#e63946; margin-bottom:15px;">Popular Links</h3>
                <ul style="list-style:none; padding:0; line-height:2;">
                    <li><a href="https://www.speedcarwash.com/terms-and-conditions" style="color:white; text-decoration:none;">› Terms & Conditions</a></li>
                    <li><a href="https://car-washer.in/privacy-policy/" style="color:white; text-decoration:none;">› Privacy Policy</a></li>
                </ul>
            </div>

        </div>

        <!-- Bottom -->
        <div style="text-align:center; margin-top:30px; border-top:1px solid rgba(255,255,255,0.2); padding-top:15px;">
            © 2025 Car Wash | All Rights Reserved
        </div>
    </footer>
    <!-- Footer End -->

</body>
</html>
