<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Car Wash Login</title>

 <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background: url('img/Bg3.jpg') no-repeat center/cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .card {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 12px;
      width: 400px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
      text-align: center;
    }

    h2 {
      color: #0a2a43;
      margin-bottom: 20px;
    }

    .input-group {
      margin-bottom: 15px;
      text-align: left;
    }

    .input-group label {
      display: block;
      margin-bottom: 6px;
      font-size: 14px;
      color: #333;
    }

    .input-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      outline: none;
      font-size: 15px;
    }

    .btn {
      width: 100%;
      padding: 12px;
      background: #ed2020;
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn:hover {
      background: #0072ff;
    }

    .links {
      margin-top: 15px;
      font-size: 14px;
    }

    .links a {
      color: #0072ff;
      text-decoration: none;
    }

 </style>
</head>

<body>
  <div class="card">
    <h2>Login to Car Wash</h2>
    <form action="" method="POST"> <!-- same file me hi submit hoga -->
      <div class="input-group">
        <label>Email</label>
        <input type="text" placeholder="Enter email" name="email" required>
      </div>
      <div class="input-group">
        <label>Password</label>
        <input type="password" placeholder="Enter password" name="password" required>
      </div>
      <button type="submit" class="btn">Login</button>
      <div class="links">
        Don’t have an account? <a href="Register.php">Register</a>
      </div>
    </form>
<?php
session_start();

// --- HANDLE FORM SUBMISSION ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // connect to DB
    $conn = mysqli_connect("localhost", "root", "", "car_wash");
    if (!$conn) { 
        die("Connection failed: " . mysqli_connect_error()); 
    }

    // get POST values and sanitize
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // validate email
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        die("<h3 style='color:red; text-align:center;'>Invalid Email format</h3>");
    }

    // check credentials
    $sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){
        $_SESSION['email'] = $email;

        // ✅ set cookie BEFORE any HTML output
        setcookie('user_email', $email, time() + (7*24*60*60), "/"); 

        // redirect to main page
        header("Location: main_page.php");
        exit();
    } else {
        $error_msg = "Invalid Email or Password";
    }

    mysqli_close($conn);
}
?>
  </div>
</body>

</html>