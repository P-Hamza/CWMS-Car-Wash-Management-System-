<?php
$msg = ''; // message to show in form

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // connect
  $conn = mysqli_connect("localhost", "root", "", "car_wash");
  if (!$conn) {
    $msg = "<div class='msg error'>Database connection failed.</div>";
  } else {
    // get raw values (same name as form input fields)
    $name     = $_POST['user_name'] ?? '';
    $email    = $_POST['email'] ?? '';
    $phone    = $_POST['mobile'] ?? '';
    $address  = $_POST['address'] ?? '';
    $password = $_POST['password'] ?? ''; // plain text (NO encryption)

    // insert data
    $insert = mysqli_prepare($conn, "INSERT INTO user(name, email, phone, address, password) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($insert, "sssss", $name, $email, $phone, $address, $password);

    if (mysqli_stmt_execute($insert)) {
      $msg = "<div class='msg success'>✅ Registration successful! <a href='Login.php'>Login here</a></div>";
    } else {
      $msg = "<div class='msg error'>⚠️ Could not save data. Try again later.</div>";
    }
    mysqli_stmt_close($insert);
    mysqli_close($conn);
  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Car Wash Register</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background: url('img/Bg3.jpg') no-repeat center/cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .card {
      background: rgba(255, 255, 255, 0.95);
      border-radius: 12px;
      width: 400px;
      padding: 30px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
      text-align: center;
    }

    h2 {
      color: #0a2a43;
      margin-bottom: 20px;
    }

    .input-group {
      margin-bottom: 15px;
      text-align: left;
    }

    .input-group label {
      display: block;
      margin-bottom: 6px;
      font-size: 14px;
      color: #333;
    }

    .input-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      outline: none;
      font-size: 15px;
    }

    .btn {
      width: 100%;
      padding: 12px;
      background: #ed2020;
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn:hover {
      background: #0072ff;
    }

    .links {
      margin-top: 15px;
      font-size: 14px;
    }

    .links a {
      color: #0072ff;
      text-decoration: none;
    }

    /* messages */
    .msg {
      margin-top: 12px;
      padding: 10px;
      border-radius: 6px;
      text-align: left;
    }

    .msg.success {
      background: #e6ffe6;
      color: #006600;
    }

    .msg.error {
      background: #ffe6e6;
      color: #990000;
    }
  </style>
</head>

<body>
  <div class="card">
    <h2>Register for Car Wash</h2>
    <form action="" method="post">
      <div class="input-group">
        <label>Username</label>
        <input type="text" name="user_name" placeholder="Enter username" required value="<?php echo htmlspecialchars($_POST['user_name'] ?? ''); ?>">
      </div>
      <div class="input-group">
        <label>Email</label>
        <input type="email" name="email" placeholder="Enter email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
      </div>
      <div class="input-group">
        <label>Mobile Number</label>
        <input type="tel" name="mobile" placeholder="Enter mobile number" required value="<?php echo htmlspecialchars($_POST['mobile'] ?? ''); ?>">
      </div>
      <div class="input-group">
        <label>Address</label>
        <input type="text" name="address" placeholder="Enter Address" required value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>">
      </div>
      <div class="input-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>
      </div>

      <button type="submit" class="btn">Register</button>

      <!-- show message just below button -->
      <?php if ($msg) echo $msg; ?>

      <div class="links">
        Already have an account? <a href="Login.php">Login</a>
      </div>
    </form>
  </div>
</body>

</html>